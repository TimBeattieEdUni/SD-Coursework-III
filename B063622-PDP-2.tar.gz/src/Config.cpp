//////////////////////////////////////////////////////////////////////////////
/// @file     Config.cpp
///
/// @brief    Implementation of class Config.
///


//////////////////////////////////////////////////////////////////////////////
//  This class's header.
#include "Config.hpp"


//////////////////////////////////////////////////////////////////////////////
//  Standard headers.
#include <iostream>
#include <stdexcept>
#include <sstream>


namespace Biology
{
	//////////////////////////////////////////////////////////////////////////////
	/// @details    Reads configuration from command-line arguments.
	///
	/// @param      argc Standard argument count.
	/// @param      argv Standard argument list.		
	///
	/// @exception  Runtime error if config could not be obtained from command line.
	///
	Config::Config(int argc, char* argv[])
		: m_cells(0)
		, m_ini_sqrls(0)
		, m_max_sqrls(0)
		, m_sim_len(0)
		, m_day_len(0.0)
	{		
		if (7 > argc)
		{
			throw std::runtime_error("usage: squirrels <cells> <squirrels> <infected> <maxsq> <simdays> <daylen>");
		}
		
		std::stringstream converter;

		converter << argv[1] 
		          << " " << argv[2] 
		          << " " << argv[3]
		          << " " << argv[4]
				  << " " << argv[5]
				  << " " << argv[6];
		
		converter >> m_cells 
		          >> m_ini_sqrls 
				  >> m_ini_inf
				  >> m_max_sqrls 
				  >> m_sim_len
				  >> m_day_len;	

 	}


	//////////////////////////////////////////////////////////////////////////////
	/// @details    Describe object destruction here.
	///
	Config::~Config()
	{

	}
	
	
	void Config::Print()
	{
		std::cout << "configuration:"
				  << "  cells="     << m_cells
				  << "  squirrels=" << m_ini_sqrls
				  << "  infected="  << m_ini_inf
				  << "  maxsq="     << m_max_sqrls
				  << "  simlen="    << m_sim_len
				  << "  daylen="    << m_day_len
				  << std::endl;
	}
	
}   //  namespace Biology
